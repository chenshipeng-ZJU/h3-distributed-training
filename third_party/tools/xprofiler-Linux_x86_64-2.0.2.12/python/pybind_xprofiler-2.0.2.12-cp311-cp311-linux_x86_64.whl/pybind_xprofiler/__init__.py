import importlib
import sys

try:
    mod = importlib.import_module('.pybind_xprofiler_cuda11', __package__)
except ImportError:
    mod = importlib.import_module('.pybind_xprofiler_cuda12', __package__)

# 将所有 public symbol 放到当前模块命名空间
for attr in getattr(mod, '__all__', []):
    globals()[attr] = getattr(mod, attr)